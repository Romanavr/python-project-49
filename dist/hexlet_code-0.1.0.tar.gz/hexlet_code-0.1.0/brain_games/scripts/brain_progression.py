from brain_games.games.game_engine import new_game


def main():
    new_game('progression')


if __name__ == '__main__':
    main()
