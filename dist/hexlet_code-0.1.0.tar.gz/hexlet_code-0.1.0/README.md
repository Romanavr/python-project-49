### Hexlet tests and linter status:
[![Actions Status](https://github.com/Romanavr/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Romanavr/python-project-49/actions)

<a href="https://codeclimate.com/github/Romanavr/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/19c3718494e3f041d781/maintainability" /></a>

Game "Brain Even"
[![asciicast](https://asciinema.org/a/DWHIJ2TUx9154wBbXPUvHwB69.png)](https://asciinema.org/a/DWHIJ2TUx9154wBbXPUvHwB69)

Game "Brain Calc"
[![asciicast](https://asciinema.org/a/abJVRI5Ga4tD6uucAz7pmqqsa.png)](https://asciinema.org/a/abJVRI5Ga4tD6uucAz7pmqqsa)

Game "Brain Gcd"
[![asciicast](https://asciinema.org/a/98lbkRA8rUFHSll6B13IBeKPH.png)](https://asciinema.org/a/98lbkRA8rUFHSll6B13IBeKPH)

Game "Brain Prime"
[![asciicast](https://asciinema.org/a/HG4sm0bYbx1f2vHbJBkBBL3WW.png)](https://asciinema.org/a/HG4sm0bYbx1f2vHbJBkBBL3WW)

Game "Brain Progression"
[![asciicast](https://asciinema.org/a/S1HkSEGMZ8JA1e4dKa70RZ2HU.png)](https://asciinema.org/a/S1HkSEGMZ8JA1e4dKa70RZ2HU)