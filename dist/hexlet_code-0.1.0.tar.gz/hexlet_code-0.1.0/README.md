### Hexlet tests and linter status:
[![Actions Status](https://github.com/Romanavr/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Romanavr/python-project-49/actions)

<a href="https://codeclimate.com/github/Romanavr/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/19c3718494e3f041d781/maintainability" /></a>

Game "Brain Even"
[![asciicast](https://asciinema.org/a/t9Iq6VYUsLNVyrMvRh3w6rWEE.png)](https://asciinema.org/a/t9Iq6VYUsLNVyrMvRh3w6rWEE)