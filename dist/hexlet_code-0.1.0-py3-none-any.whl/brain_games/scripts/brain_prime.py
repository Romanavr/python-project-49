from random import randrange
from brain_games.game_engine import start_game

GAME_DESCRIPTION = 'Answer "yes" if given number is prime. Otherwise answer "no".'


def game_handler():
    number = randrange(1, 101)
    if number < 1 or number % 2 == 0:
        return number, 'no'
    for i in range(2, number, 2):
        if number % i == 0:
            return number, 'no'
    return number, 'yes'

def main():
    start_game(GAME_DESCRIPTION, game_handler)


if __name__ == '__main__':
    main()
