from random import randrange
from game_engine import start_game

GAME_DESCRIPTION = 'What is the result of the expression?'


def handler():
    operator = ['+', '-', '*'][randrange(0, 3)]
    operand_a = randrange(100)
    operand_b = randrange(100)
    question = f'{operand_a} {operator} {operand_b}'
    answer = eval(question)

    return question, answer

def main():
    start_game(GAME_DESCRIPTION, handler)


if __name__ == '__main__':
    main()
